package com.example.demoapp;

import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.view.Menu;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;




public class MainActivity extends AppCompatActivity {
    //viewing objects
    Button btn;
    EditText et;
    String st;
    ImageView iv;

    //Variables for translation and display
    int phraseIndex=0;
    String letters;
    String display;

    //array libraries for images
    char letterIndex[]={'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',' '};







    //ASL Image resources
    int aslPic[]={R.drawable.a_test, R.drawable.b_test, R.drawable.c_test, R.drawable.d_test, R.drawable.f_test,
                  R.drawable.e_test,R.drawable.f_test, R.drawable.g_test,R.drawable.h_test,R.drawable.i_test,
                  R.drawable.j_test,R.drawable.k_test,R.drawable.l_test,R.drawable.m_test,R.drawable.n_test,
                  R.drawable.o_test,R.drawable.p_test,R.drawable.q_test,R.drawable.r_test,R.drawable.s_test,
                  R.drawable.t_test,R.drawable.u_test,R.drawable.v_test,R.drawable.w_test,R.drawable.x_test,
                  R.drawable.y_test,R.drawable.z_test,R.drawable.space_test};



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn=findViewById(R.id.Button);
        et=findViewById(R.id.edittext);
        iv=findViewById(R.id.imagetranslate);
        //selecting the text typed in the input
        et.setSelectAllOnFocus(true);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(MainActivity.this,SecondActivity.class);
                st=et.getText().toString();
                i.putExtra( "Value",st);
                startActivity(i);
                finish();


            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //Inflate the menu----adding items to the action bar if present
        getMenuInflater().inflate(R.menu.activity_main,menu);
        return true;
    }

    public void setString(View v) {
        InputMethodManager imm = (InputMethodManager)this.getSystemService(Service.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(v.getWindowToken(),0);
        phraseIndex=0;
        Editable input = et.getText();
        String phrase=input.toString();
        letters=phrase.toLowerCase();
    }

    public void translateLetter(View v) {
        if (letters!=null){
            char currentLetter=letters.charAt(phraseIndex);
            display += currentLetter;
            for (int i = 0; i < letterIndex.length; i++) {
                if (letterIndex[i]==currentLetter){
                    iv.setImageResource(aslPic[i]);
                }

            }
            phraseIndex++;
            if (phraseIndex > letters.length()-1){
                phraseIndex=0;
                display="";
            }
        }
    }


}


